/*
** esc.c for esc in /home/alies_a/rendu/gfx_raytracer2
** 
** Made by alies_a
** Login   <alies_a@epitech.net>
** 
** Started on  Wed Apr 20 16:13:02 2016 alies_a
** Last update Wed Apr 20 16:41:02 2016 alies_a
*/

#include "core.h"

int     key_esc(t_data *data)
{
  (void)data;
  return (1);
}
